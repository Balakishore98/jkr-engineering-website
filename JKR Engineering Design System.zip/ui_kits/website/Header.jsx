/* JKR Engineering website — Header / top nav */
const { Button: JKRButton } = window.JKREngineeringDesignSystem_a889f1;

function Header({ onNav }) {
  const links = [
    { id: 'services', label: 'What we do' },
    { id: 'why', label: 'Why JKR' },
    { id: 'about', label: 'About' },
    { id: 'contact', label: 'Contact' },
  ];
  const link = (l) => (
    <a
      key={l.id}
      href={'#' + l.id}
      onClick={(e) => { e.preventDefault(); onNav && onNav(l.id); }}
      style={{
        fontFamily: 'var(--font-sans)', fontSize: 15, fontWeight: 500,
        color: 'var(--text-body)', textDecoration: 'none', padding: '6px 2px',
        borderBottom: '2px solid transparent', transition: 'color var(--dur) var(--ease-out), border-color var(--dur) var(--ease-out)',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.color = 'var(--text-strong)'; e.currentTarget.style.borderColor = 'var(--accent)'; }}
      onMouseLeave={(e) => { e.currentTarget.style.color = 'var(--text-body)'; e.currentTarget.style.borderColor = 'transparent'; }}
    >
      {l.label}
    </a>
  );
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 50, background: 'rgba(255,255,255,0.88)',
      backdropFilter: 'blur(10px)', borderBottom: '1px solid var(--border)',
    }}>
      <div style={{
        maxWidth: 'var(--container)', margin: '0 auto', padding: '14px 32px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <a href="#top" onClick={(e) => { e.preventDefault(); onNav && onNav('top'); }} style={{ display: 'flex' }}>
          <img src="../../assets/logo-lockup.svg" alt="JKR Engineering" height="38" />
        </a>
        <nav style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
          <div style={{ display: 'flex', gap: 26 }}>{links.map(link)}</div>
          <JKRButton variant="primary" size="sm" onClick={() => onNav && onNav('contact')}>Request a quote</JKRButton>
        </nav>
      </div>
    </header>
  );
}
window.Header = Header;
