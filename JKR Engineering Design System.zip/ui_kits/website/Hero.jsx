/* JKR Engineering website — Hero */
const { Button: HeroButton, SectionLabel: HeroLabel, Badge: HeroBadge } = window.JKREngineeringDesignSystem_a889f1;

function Hero({ onNav }) {
  return (
    <section id="top" style={{ background: 'var(--bg-dark)', position: 'relative', overflow: 'hidden' }}>
      {/* faint blueprint grid */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.5,
        backgroundImage: 'linear-gradient(var(--steel-800) 1px, transparent 1px), linear-gradient(90deg, var(--steel-800) 1px, transparent 1px)',
        backgroundSize: '48px 48px',
        maskImage: 'radial-gradient(120% 90% at 70% 10%, #000 30%, transparent 80%)',
        WebkitMaskImage: 'radial-gradient(120% 90% at 70% 10%, #000 30%, transparent 80%)',
      }} />
      <div style={{
        position: 'relative', maxWidth: 'var(--container)', margin: '0 auto',
        padding: 'clamp(56px, 8vw, 104px) 32px', display: 'grid',
        gridTemplateColumns: '1.05fr 0.95fr', gap: 48, alignItems: 'center',
      }}>
        <div>
          <HeroLabel tone="dark">CNC Manufacturing · Est. 2005</HeroLabel>
          <h1 style={{
            margin: '20px 0 0', fontFamily: 'var(--font-display)', fontWeight: 700,
            fontSize: 'var(--fs-display)', lineHeight: 1.04, letterSpacing: 'var(--ls-tight)',
            color: 'var(--text-on-dark)',
          }}>
            Machine tools &amp; parts,<br /><span style={{ color: 'var(--accent)' }}>made to exact spec.</span>
          </h1>
          <p style={{
            margin: '22px 0 0', maxWidth: '46ch', fontSize: 18, lineHeight: 1.65,
            color: 'var(--text-on-dark-muted)',
          }}>
            JKR Engineering manufactures CNC machine tools and precision components
            to your drawings — built for quality, delivered on time, since 2005.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
            <HeroButton variant="primary" size="lg" onClick={() => onNav && onNav('contact')}>Request a quote</HeroButton>
            <HeroButton variant="dark" size="lg" onClick={() => onNav && onNav('services')} iconRight={<span>→</span>}>What we do</HeroButton>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 28 }}>
            <HeroBadge variant="dark">±0.01 mm tolerance</HeroBadge>
            <HeroBadge variant="dark">Made to order</HeroBadge>
            <HeroBadge variant="dark">On-time delivery</HeroBadge>
          </div>
        </div>
        <div style={{ position: 'relative' }}>
          <img src="../../assets/machine-placeholder-4x3.svg" alt="CNC machine"
            style={{ width: '100%', height: 'auto', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-dark)', boxShadow: 'var(--shadow-lg)' }} />
          <div style={{
            position: 'absolute', bottom: -14, left: -14, background: 'var(--accent)',
            color: 'var(--accent-contrast)', padding: '10px 16px', borderRadius: 'var(--radius-sm)',
            fontFamily: 'var(--font-mono)', fontSize: 12, letterSpacing: '0.1em', fontWeight: 600,
            boxShadow: 'var(--shadow-accent)',
          }}>
            EST. MAY 2005
          </div>
        </div>
      </div>
    </section>
  );
}
window.Hero = Hero;
